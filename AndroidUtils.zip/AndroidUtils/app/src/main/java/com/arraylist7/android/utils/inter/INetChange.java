package com.arraylist7.android.utils.inter;

import com.arraylist7.android.utils.NetState;

public interface INetChange {
    public void onNetChange(NetState state);
}
