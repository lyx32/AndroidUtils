package com.arraylist7.android.utils.inter;

import android.content.Context;
import android.os.Message;

import com.arraylist7.android.utils.handler.NHandler;

/**
 * Created by Administrator on 2017/11/9 0009.
 */

public interface IHandler {

    public void handlerMsg(NHandler handler,Message msg);
}
