package com.arraylist7.android.utils.listener;

public class HtmlParserListenerAdapter implements HtmlParserListener {


    @Override
    public void onLinkClick(String href, String text) {

    }

    @Override
    public void onTelephoneClick(String href, String text) {

    }

    @Override
    public void onEmailClick(String href, String text) {

    }

    @Override
    public void onAtuserClick(String href, String text) {

    }

    @Override
    public void onTopicClick(String href, String text) {

    }

    @Override
    public void onImageClick(String src, String alt) {

    }

    @Override
    public void onOtherClick(String group0, String group1) {

    }


}
