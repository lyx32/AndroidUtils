package com.arraylist7.android.utils.inter;

public interface IScreen {
    public void onScreenLock(boolean isLock);
}
