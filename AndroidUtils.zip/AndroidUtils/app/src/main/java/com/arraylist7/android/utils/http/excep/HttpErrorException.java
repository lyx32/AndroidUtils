package com.arraylist7.android.utils.http.excep;

public class HttpErrorException extends HttpException {

    public HttpErrorException(String message, Throwable cause) {
        super(message, cause);
    }

}
