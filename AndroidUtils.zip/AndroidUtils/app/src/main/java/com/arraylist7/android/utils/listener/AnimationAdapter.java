package com.arraylist7.android.utils.listener;

import android.view.animation.Animation;

/**
 * Created by Administrator on 2017/2/16.
 */

public class AnimationAdapter implements Animation.AnimationListener {

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
