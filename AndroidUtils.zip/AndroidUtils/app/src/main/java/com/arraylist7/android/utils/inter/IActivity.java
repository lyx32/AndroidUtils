package com.arraylist7.android.utils.inter;

/**
 * Created by Administrator on 2016/5/22.
 */
public interface IActivity {

    public int getLayoutId();

    public void initWidget();

    public void initData();

    public void initListener();


}
