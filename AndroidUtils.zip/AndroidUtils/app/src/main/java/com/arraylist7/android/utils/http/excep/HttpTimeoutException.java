package com.arraylist7.android.utils.http.excep;

public class HttpTimeoutException extends HttpException {


    public HttpTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
}
