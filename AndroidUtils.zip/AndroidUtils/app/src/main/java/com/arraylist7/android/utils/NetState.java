package com.arraylist7.android.utils;

public enum NetState {
	NET_NO, NET_2G, NET_3G, NET_4G, NET_WIFI, NET_UNKNOWN
}
