package com.arraylist7.android.utils.http.excep;

public class HttpException extends Exception {

    public HttpException(String message, Throwable cause) {
        super(message, cause);
    }
}
